### This is the directory in which EnergyPlus installation binaries are located

## The automated scripts look for $MOUNT/energyplus/software/energyplus-installer.sh

# If the binaries are not manually placed here (to suit a particular version/revision, 8.5.0 will be downloaded from the web
